/*====================================================================================
|                 Luis Alejandro Cabanillas Prudencio  DNI: 04236930P                |
|                    Álvaro de las Heras Fernández  DNI: 03146833L                   |
|                                                                                    |
|         16384 Juego que simula al 2048 implementado con Scala                      |
====================================================================================*/

//------------------------------FUNCIONES GENERICAS---------------------------------
object prueba2 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(849); 
//Obtiene el valor de una posicion indice del tablero
def obtener(tablero: List[Int], indice: Int): Int = {
  if (!tablero.isEmpty) {
    if (indice == 1) tablero.head
    else obtener(tablero.tail, indice - 1)
  } else -1
};System.out.println("""obtener: (tablero: List[Int], indice: Int)Int""");$skip(132); 


def crearValorRandom(): Int = {
  val list = List(2,4)
  val random = util.Random;
  val colo = list(random.nextInt(2))
  colo
};System.out.println("""crearValorRandom: ()Int""");$skip(110); 

def crearRandomPos(tam:Int): Int = {
  val random = util.Random;
  val pos = random.nextInt(tam) + 1
  pos
};System.out.println("""crearRandomPos: (tam: Int)Int""");$skip(275); 

def poner(lista: List[Int]): List[Int] = {
  val pos = crearRandomPos(lista.length)
  val col = crearValorRandom()
  if (lista.isEmpty) Nil
    if (obtener(lista,pos)==0)
      if (pos == 1) col :: lista.tail
      else lista.head :: poner(lista.tail)
  else poner(lista)
};System.out.println("""poner: (lista: List[Int])List[Int]""");$skip(171); 

def poner2(l: List[Int], valor: Int, pos: Int): List[Int] = {
  if (l.isEmpty) Nil
  else if (pos == 1) valor :: l.tail
  else l.head :: poner2(l.tail, valor, pos - 1)
};System.out.println("""poner2: (l: List[Int], valor: Int, pos: Int)List[Int]""");$skip(139); 

def generarTab(filas: Int, columnas: Int, tam: Int): List[Int] = {
  if (tam == 0) Nil
  else 0 :: generarTab(filas, columnas, tam - 1)
};System.out.println("""generarTab: (filas: Int, columnas: Int, tam: Int)List[Int]""");$skip(189); 

def huecosLibres(tablero:List[Int]):Int = {
  if (tablero.length > 0){
    if (tablero.head == 0)
      huecosLibres(tablero.tail)+1
    else
      huecosLibres(tablero.tail)
  } else 0
};System.out.println("""huecosLibres: (tablero: List[Int])Int""");$skip(220); 
def rellenarTab(tablero: List[Int], numCasillas: Int): List[Int] = {
  if (tablero.isEmpty) Nil
  else if ((huecosLibres(tablero)>0) && (numCasillas != 0)){ rellenarTab(poner(tablero), numCasillas - 1)}
  else tablero
};System.out.println("""rellenarTab: (tablero: List[Int], numCasillas: Int)List[Int]""");$skip(196); 

def imprimir(lista: List[Int], columnas: Int) {
  if (!lista.isEmpty) {
    if (lista.length % columnas == 0) println()
    print("|" + lista.head + "|")
    imprimir(lista.tail, columnas)
  }
};System.out.println("""imprimir: (lista: List[Int], columnas: Int)Unit""");$skip(216); 

def eliminarSumar(tablero: List[Int], indice: Int): List[Int] = {
  if (!tablero.isEmpty) {
    if (indice == 1) 0 :: tablero.tail
    else tablero.head :: eliminarSumar(tablero.tail, indice - 1)
  } else tablero
};System.out.println("""eliminarSumar: (tablero: List[Int], indice: Int)List[Int]""");$skip(219); 


//--------------------------FUNCIONES AUXILIARES DE MOVIMIENTO--------------------------

def reverse(lista: List[Int]): List[Int] = {
  if (lista.length == 0) lista
  else reverse(lista.tail) ::: lista.head :: Nil
};System.out.println("""reverse: (lista: List[Int])List[Int]""");$skip(471); 

//------------------------   MOVIMIENTOS   -------------------------------

def moverAbajo(tablero: List[Int], columnas: Int): List[Int] = {
  if (!tablero.isEmpty) {
    if (tablero.head > 0) {
      if (obtener(tablero, columnas + 1) == 0) moverAbajo(poner2(eliminarSumar(tablero, 1), tablero.head, columnas + 1), columnas)
      else tablero.head :: moverAbajo(tablero.tail, columnas)

    } else tablero.head :: moverAbajo(tablero.tail, columnas)
  } else tablero
};System.out.println("""moverAbajo: (tablero: List[Int], columnas: Int)List[Int]""");$skip(422); 
def moverDerecha(tablero: List[Int], columnas: Int): List[Int] = {
  if (!tablero.isEmpty) {
    if ((tablero.head > 0)) {
      if ((obtener(tablero, 2) == 0) && ((tablero.length) % columnas != 1)) moverDerecha(poner2(eliminarSumar(tablero, 1), tablero.head, 2), columnas)
      else tablero.head :: moverDerecha(tablero.tail, columnas)

    } else tablero.head :: moverDerecha(tablero.tail, columnas)
  } else tablero
};System.out.println("""moverDerecha: (tablero: List[Int], columnas: Int)List[Int]""");$skip(499); 
def moverArriba(tablero: List[Int], columnas: Int): List[Int] = {
  val tablero_aux = reverse(tablero)
  if (!tablero_aux.isEmpty) {
    if (tablero_aux.head > 0) {
      if (obtener(tablero_aux, columnas + 1) == 0) reverse(moverAbajo(poner2(eliminarSumar(tablero_aux, 1), tablero_aux.head, columnas + 1), columnas))
      else reverse(tablero_aux.head :: moverAbajo(tablero_aux.tail, columnas))

    } else reverse(tablero_aux.head :: moverAbajo(tablero_aux.tail, columnas))
  } else tablero_aux
};System.out.println("""moverArriba: (tablero: List[Int], columnas: Int)List[Int]""");$skip(502); 
  def moverIzquierda(tablero: List[Int], columnas: Int): List[Int] = {
    val tablero_aux = reverse(tablero)
    if (!tablero_aux.isEmpty) {
      if (tablero_aux.head > 0) {
        if (obtener(tablero_aux,2) == 0) reverse(moverDerecha(poner2(eliminarSumar(tablero_aux, 1), tablero_aux.head,2), columnas))
        else reverse(tablero_aux.head :: moverDerecha(tablero_aux.tail, columnas))

      } else reverse(tablero_aux.head :: moverDerecha(tablero_aux.tail, columnas))
    } else tablero_aux
  };System.out.println("""moverIzquierda: (tablero: List[Int], columnas: Int)List[Int]""");$skip(276); 

//------------------------ MOVIMIENTO DE TODAS LAS CASILLAS-------------------------------

def moverTodoAbajo(tablero: List[Int], filas: Int, columnas: Int): List[Int] = {
  if (filas == 1) tablero
  else moverTodoAbajo(moverAbajo(tablero, columnas), filas - 1, columnas)
};System.out.println("""moverTodoAbajo: (tablero: List[Int], filas: Int, columnas: Int)List[Int]""");$skip(186); 
def moverTodoArriba(tablero: List[Int], filas: Int, columnas: Int): List[Int] = {
  if (filas == 1) tablero
  else moverTodoArriba(moverArriba(tablero, columnas), filas - 1, columnas)
};System.out.println("""moverTodoArriba: (tablero: List[Int], filas: Int, columnas: Int)List[Int]""");$skip(189); 
def moverTodoDerecha(tablero: List[Int], filas: Int, columnas: Int): List[Int] = {
  if (filas == 1) tablero
  else moverTodoDerecha(moverDerecha(tablero, columnas), filas - 1, columnas)
};System.out.println("""moverTodoDerecha: (tablero: List[Int], filas: Int, columnas: Int)List[Int]""");$skip(195); 
def moverTodoIzquierda(tablero: List[Int], filas: Int, columnas: Int): List[Int] = {
  if (filas == 1) tablero
  else moverTodoIzquierda(moverIzquierda(tablero, columnas), filas - 1, columnas)
};System.out.println("""moverTodoIzquierda: (tablero: List[Int], filas: Int, columnas: Int)List[Int]""");$skip(438); 

def sumarIzquierda(tablero: List[Int],columnas:Int):List[Int]={
  if (!tablero.isEmpty) {
    if ((tablero.head > 0)) {
      if ((obtener(tablero, 2) == tablero.head) && ((tablero.length) % columnas != 1)) sumarIzquierda(poner2(eliminarSumar(tablero, 2), tablero.head*2, 1), columnas)
      else tablero.head :: sumarIzquierda(tablero.tail, columnas)
    } else tablero.head :: sumarIzquierda(tablero.tail, columnas)
  } else tablero
};System.out.println("""sumarIzquierda: (tablero: List[Int], columnas: Int)List[Int]""");$skip(408); 
def sumarArriba(tablero: List[Int],columnas:Int):List[Int]={
  if (!tablero.isEmpty) {
    if ((tablero.head > 0)) {
      if (obtener(tablero, columnas + 1) == tablero.head) sumarArriba(poner2(eliminarSumar(tablero, columnas + 1), tablero.head*2, 1), columnas)
      else tablero.head :: sumarArriba(tablero.tail, columnas)

    } else tablero.head :: sumarArriba(tablero.tail, columnas)
  } else tablero
};System.out.println("""sumarArriba: (tablero: List[Int], columnas: Int)List[Int]""");$skip(105); 

//------------------------------- PRUEBAS ----------------------------------------------

val filas = 6;System.out.println("""filas  : Int = """ + $show(filas ));$skip(17); 
val columnas = 6;System.out.println("""columnas  : Int = """ + $show(columnas ));$skip(27); 
val tam = filas * columnas;System.out.println("""tam  : Int = """ + $show(tam ));$skip(37); 

val tablero = generarTab(6, 6, tam);System.out.println("""tablero  : List[Int] = """ + $show(tablero ));$skip(46); 
val tableroRelleno = rellenarTab(tablero, 16);System.out.println("""tableroRelleno  : List[Int] = """ + $show(tableroRelleno ));$skip(29); 

imprimir(tableroRelleno, 6);$skip(147); 

imprimir(moverTodoDerecha(reverse(sumarIzquierda(reverse(moverTodoDerecha(tableroRelleno, filas,columnas)),columnas)),filas ,columnas), columnas);$skip(133); 

imprimir(moverTodoIzquierda(sumarIzquierda(moverTodoIzquierda(tableroRelleno,filas ,columnas),columnas),filas ,columnas), columnas);$skip(124); 

imprimir(moverTodoArriba(sumarArriba(moverTodoArriba(tableroRelleno,filas ,columnas),columnas),filas ,columnas), columnas);$skip(140); 

imprimir(moverTodoAbajo(reverse(sumarArriba(reverse(moverTodoAbajo(tableroRelleno,filas ,columnas)),columnas)),filas ,columnas), columnas);$skip(26); 
         
   print("fin")}
         
      
         
         
         
         
                                                  
}
